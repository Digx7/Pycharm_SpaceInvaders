import pygame as pg
from settings import Settings
import game_functions as gf
from pygame.sprite import Group

from laser import Lasers
from ship import Ship
from sound import Sound
from Alien import Aliens
from game_stats import GameStats


class Game:
    def __init__(self):
        pg.init()
        self.settings = Settings()
        size = self.settings.screen_width, self.settings.screen_height   # tuple
        self.screen = pg.display.set_mode(size=size)
        pg.display.set_caption("Alien Invasion")

        self.clock = pg.time.Clock()
        self.clock.tick(self.settings.fps)

        self.stats = GameStats(self.settings)

        self.sound = Sound(bg_music="sounds/startrek.wav")
        laser_group = Group()
        self.lasers = Lasers(laser_group, self.settings)
        self.ship = Ship(self.settings, self.screen, self.sound, self.lasers)

        alien_group = Group()
        self.aliens = Aliens(alien_group, self.settings)

    def play(self):
        self.sound.play_bg()
        gf.create_fleet(self.settings, self.screen, self.ship, self.aliens)
        while True:     # at the moment, only exits in gf.check_events if Ctrl/Cmd-Q pressed
            # update calls
            gf.check_events(self.settings, self.ship)
            if self.stats.game_active:
                gf.try_to_make_new_fleet(self.settings, self.screen, self.ship, self.aliens, self.lasers)
                self.ship.update()
                self.lasers.update()
                self.aliens.update()
                gf.check_laser_collisions(self.aliens, self.lasers)
                gf.check_player_hit_by_aliens(self.settings, self.stats, self.screen, self.ship, self.aliens, self.lasers)
                gf.check_aliens_bottom(self.settings, self.stats, self.screen, self.ship, self.aliens, self.lasers)

            # draw calls
            self.screen.fill(self.settings.bg_color)
            self.lasers.draw()
            self.aliens.draw()
            self.ship.draw()
            pg.display.flip()


def main():
    g = Game()
    g.play()


if __name__ == '__main__':
    main()
