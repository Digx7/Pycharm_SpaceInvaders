class GameStats():
    """Track statistics for Alien Invasion"""

    def __init__(self, settings):
        """Initialize stats"""
        self.settings = settings
        self.reset_stats()

        self.game_active = True

    def reset_stats(self):
        """Initialize stats. Can be reset at runtime"""
        self.lives_left = self.settings.total_lives
