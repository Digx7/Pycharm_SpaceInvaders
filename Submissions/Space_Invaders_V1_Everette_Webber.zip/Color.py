class ColorPalette():
    def __init__(self, **colors):
        self.color = colors
        self.bg_color = colors["bg"]
