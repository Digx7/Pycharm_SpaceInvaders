import pygame as pg
from settings import Settings
import game_functions as gf
from pygame.sprite import Group

from laser import Lasers
from ship import Ship
from sound import Sound
from Alien import Aliens
from game_stats import GameStats
from button import Buttons
from UI import GameUI


class Game:
    def __init__(self):
        pg.init()
        self.settings = Settings()
        size = self.settings.screen_width, self.settings.screen_height   # tuple
        self.screen = pg.display.set_mode(size=size)
        pg.display.set_caption("Alien Invasion")

        self.clock = pg.time.Clock()
        self.clock.tick(self.settings.fps)

        self.stats = GameStats(self.settings)

        self.buttons = Buttons(self.settings, self.screen, play_button="Play")

        self.game_ui = GameUI(self.settings, self.screen, self.stats)

        self.sound = Sound(bg_music="sounds/startrek.wav")
        laser_group = Group()
        self.lasers = Lasers(laser_group, self.settings)
        self.ship = Ship(self.settings, self.screen, self.sound, self.lasers)

        alien_group = Group()
        self.aliens = Aliens(alien_group, self.settings)

    def play(self):
        self.sound.play_bg()
        while True:     # at the moment, only exits in gf.check_events if Ctrl/Cmd-Q pressed
            # update calls
            if not self.stats.game_active:
                gf.start_menu_update(self)
                gf.start_menu_draw(self)
            if self.stats.game_active:
                gf.main_update(self)
                gf.main_draw(self)
            pg.display.flip()


def main():
    g = Game()
    g.play()


if __name__ == '__main__':
    main()
