import pygame
from pygame.sprite import Sprite


class Aliens:
    def __init__(self, alien_group, settings):
        self.aliens = alien_group
        self.settings = settings

    def spawn(self, alien):
        self.aliens.add(alien)

    def update(self):
        self.check_fleet_edges()
        self.aliens.update()
        # TODO

    def draw(self):
        for alien in self.aliens.sprites():
            alien.draw()

    def check_fleet_edges(self):
        """Respond appropriately if any aliens have reached an edge."""
        for alien in self.aliens.sprites():
            if alien.check_edges():
                self.change_fleet_direction()
                break

    def change_fleet_direction(self):
        """Drop the entire fleet and change the fleet's direction"""
        for alien in self.aliens.sprites():
            alien.rect.y += self.settings.alien_drop_speed_factor
        self.settings.alien_move_direction *= -1


class Alien(Sprite):
    """A class to represent a single alien in the fleet."""
    def __init__(self, settings, screen):
        """Initialize the alien and set its starting position."""

        super(Alien, self).__init__()
        self.screen = screen
        self.settings = settings

        # Load the alien image and set its rect attribute.
        self.image = pygame.image.load('images/alien.bmp')
        self.rect = self.image.get_rect()

        # Start each new alien near the top left of the screen.
        self.rect.x = self.rect.width
        self.rect.y = self.rect.height

        # Store the alien's exact position.
        self.x = float(self.rect.x)

    def update(self):

        # Move the alien
        self.x += (self.settings.alien_left_right_speed_factor * self.settings.alien_move_direction)
        self.rect.x = self.x

        self.draw()
        # TODO

    def draw(self):
        """Draw the alien at its current location."""
        self.screen.blit(self.image, self.rect)

    def check_edges(self):
        """Return True if alien is at edge of screen"""
        screen_rect = self.screen.get_rect()
        if self.rect.right >= screen_rect.right:
            return True
        elif self.rect.left <= 0:
            return True
