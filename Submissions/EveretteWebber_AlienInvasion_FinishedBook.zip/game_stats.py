class GameStats():
    """Track statistics for Alien Invasion"""

    def __init__(self, settings):
        """Initialize stats"""
        self.settings = settings
        self.reset_stats()

        self.high_score = self.score
        self.game_active = False

    def reset_stats(self):
        """Initialize stats. Can be reset at runtime"""
        self.lives_left = self.settings.total_lives
        self.score = 0
        self.level = 1

    def check_high_score(self):
        if self.score > self.high_score:
            self.high_score = self.score
            return True
