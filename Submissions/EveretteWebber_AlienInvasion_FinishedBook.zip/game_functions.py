import sys
from time import sleep

import pygame
import pygame as pg
from vector import Vector
from Alien import *

movement = {pg.K_LEFT: Vector(-1, 0),   # dictionary to map keys to Vector velocities
            pg.K_RIGHT: Vector(1, 0),
            pg.K_UP: Vector(0, -1),
            pg.K_DOWN: Vector(0, 1)
            }


def start_menu_update(g):
    pg.mouse.set_visible(True)
    check_events(g.settings, g.ship, g.buttons, g.stats)
    g.ship.center_ship()


def start_menu_draw(g):
    g.screen.fill(g.settings.bg_color)
    g.buttons.draw_button("play_button")
    g.ship.draw()


def main_update(g):
    pg.mouse.set_visible(False)
    check_events(g.settings, g.ship, g.buttons, g.stats)

    try_to_make_new_fleet(g.settings, g.stats, g.screen, g.ship, g.aliens, g.lasers)

    g.ship.update()
    g.lasers.update()
    g.aliens.update()

    check_laser_collisions(g.settings, g.stats, g.game_ui, g.aliens, g.lasers)
    check_player_hit_by_aliens(g.settings, g.stats, g.screen, g.ship, g.aliens, g.lasers)
    check_aliens_bottom(g.settings, g.stats, g.screen, g.ship, g.aliens, g.lasers)

    g.game_ui.update()


def main_draw(g):
    g.screen.fill(g.settings.bg_color)
    g.lasers.draw()
    g.aliens.draw()
    g.ship.draw()
    g.game_ui.draw()

  
def check_keydown_events(event, settings, ship):
    key = event.key
    if key == pg.K_q:
        sys.exit()
    elif key == pg.K_SPACE:
        ship.shooting = True
    elif key in movement.keys(): ship.vel = settings.ship_speed_factor * movement[key]


def check_keyup_events(event, ship):
    key = event.key
    if key == pg.K_SPACE: ship.shooting = False
    elif key in movement.keys(): ship.vel = Vector()


def check_events(settings, ship, buttons, stats):
    for event in pg.event.get():
        if event.type == pg.QUIT: sys.exit()
        elif event.type == pg.KEYDOWN: 
            check_keydown_events(event=event, settings=settings, ship=ship)
        elif event.type == pg.KEYUP: check_keyup_events(event=event, ship=ship)
        elif event.type == pygame.MOUSEBUTTONDOWN:
            print("MOUSEBUTTONDOWN")
            mouse_x, mouse_y = pygame.mouse.get_pos()
            if not stats.game_active and buttons.check_button("play_button", mouse_x, mouse_y):
                print("PLay Button Was Clicked")
                on_play_click(stats)


def on_play_click(stats):
    stats.reset_stats()
    stats.game_active = True


def clamp(posn, rect, settings):
    left, top = posn.x, posn.y
    width, height = rect.width, rect.height
    left = max(0, min(left, settings.screen_width - width))
    top = max(0, min(top, settings.screen_height - height))
    return Vector(x=left, y=top), pg.Rect(left, top, width, height)

# alien fleet functions


def get_number_rows(settings, ship_height, alien_height):
    """Determine the number of rows of aliens that fit on the screen."""
    available_space_y = (settings.screen_height - (3 * alien_height) - ship_height)
    number_rows = int(available_space_y / (2 * alien_height))
    return number_rows


def get_number_aliens_x(settings, alien_width):
    """Determine the number of aliens that fit in row"""
    available_space_x = settings.screen_width - 2 * alien_width
    number_aliens_x = int(available_space_x / (2 * alien_width))
    return number_aliens_x


def create_alien(settings, screen, aliens, alien_number, row_number):
    """Create an alien and place it in the row"""
    alien = Alien(settings, screen)
    alien_width = alien.rect.width
    alien.x = alien_width + 2 * alien_width * alien_number
    alien.rect.x = alien.x
    alien.rect.y = alien.rect.height + 2 * alien.rect.height * row_number
    aliens.spawn(alien)


def create_fleet(settings, screen, ship, aliens):
    """Create a full fleet of aliens"""
    # Create an alien and find the number of aliens in a row
    alien = Alien(settings, screen)
    number_aliens_x = get_number_aliens_x(settings, alien.rect.width)
    number_rows = get_number_rows(settings, ship.rect.height, alien.rect.height)

    # Create the first row of aliens
    for row_number in range(number_rows):
        for alien_number in range(number_aliens_x):
            create_alien(settings, screen, aliens, alien_number, row_number)


def check_laser_collisions(settings, stats, ui, aliens, lasers):
    """Checks if the lasers have collided with any aliens.  Deletes both if collsion is detected"""
    collisions = pygame.sprite.groupcollide(lasers.lasers, aliens.aliens, True, True)
    if collisions:
        for aliens in collisions.values():
            stats.score += settings.alien_points * len(aliens)
            ui.update()


def try_to_make_new_fleet(settings, stats, screen, ship, aliens, lasers):
    """Try's to make a new alien fleet if all aliens are dead"""
    if len(aliens.aliens) == 0:
        # Destroy existing bullets and create new fleet.
        lasers.lasers.empty()
        settings.increase_speed()

        stats.level += 1

        create_fleet(settings, screen, ship, aliens)


def check_player_hit_by_aliens(settings, stats, screen, ship, aliens, lasers):
    """Check if the player was hit"""
    if pygame.sprite.spritecollideany(ship, aliens.aliens):
        print("Ship hit!!!")
        ship_hit(settings, stats, screen, ship, aliens, lasers)


def ship_hit(settings, stats, screen, ship, aliens, lasers):
    """Respond to ship being hit by alien."""
    if stats.lives_left > 0:
        # Decrement lives_left
        stats.lives_left -= 1

        # Empty the list of aliens and bullets
        aliens.aliens.empty()
        lasers.lasers.empty()

        # Create a new fleet and center the ship
        create_fleet(settings, screen, ship, aliens)
        ship.center_ship()

        # Pause
        sleep(0.5)
    else:
        stats.game_active = False
        stats.check_high_score()


def check_aliens_bottom(settings, stats, screen, ship, aliens, lasers):
    """Check if any aliens have reached the bottom of the screen."""
    screen_rect = screen.get_rect()
    for alien in aliens.aliens.sprites():
        if alien.rect.bottom >= screen_rect.bottom:
            ship_hit(settings, stats, screen, ship, aliens, lasers)
            break